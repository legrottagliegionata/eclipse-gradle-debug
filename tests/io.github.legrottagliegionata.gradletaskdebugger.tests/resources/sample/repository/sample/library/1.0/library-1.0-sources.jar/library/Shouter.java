package library;

/** A class of an external library, published with its sources. */
public class Shouter {
  public static String shout(String text) {
    String shouted = text.toUpperCase();
    return shouted + "!";
  }
}
